package com.capgemini.hms.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.capgemini.hms.Exception.HotelException;
import com.capgemini.hms.dto.BookingDetails;
import com.capgemini.hms.dto.Hotel;
import com.capgemini.hms.dto.RoomDetails;
import com.capgemini.hms.service.HotelServiceImpl;
import com.capgemini.hms.service.IHotelService;


@WebServlet("*.hb")
public class HotelController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	ServletConfig  conf;
	IHotelService hotelService;
    
    
    public HotelController()
    {
    	hotelService=new HotelServiceImpl();
          
        }
        
	public void init(ServletConfig config) throws ServletException {
		
	}

	
	public void destroy() {
		
	}

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		doPost(request,response);
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		String url="" ;
		String action = request.getServletPath();			
		
		switch (action)
		{
		case "/login.hb":
			
			String username= request.getParameter("txtUnm");
			String password= request.getParameter("txtPwd");
			
			if(username.equals("admin") && password.equals("admin"))
			{
				url="AdminIndex.jsp";
			}
			else
			{
				url="ErrorPage.jsp";
				
				
			}
			break;
				
			
			


		case "/addHotel.hb":
			String city = request.getParameter("city");
			String hotelName =request.getParameter("hotelName");
			String addressHotel = request.getParameter("address");
			String description = request.getParameter("description");
			String rate = request.getParameter("nightRate");
			
			//System.out.println(rate);
			//int Rate=Integer.parseInt(rate);
			Float nightRate = Float.parseFloat(rate);
			String phoneOne = request.getParameter("phoneOne");
			String phoneTwo = request.getParameter("phoneTwo");
			String rating = request.getParameter("rating");
			String emailHotel = request.getParameter("email");
			String fax = request.getParameter("fax");
			
			Hotel hotel = new Hotel();
			
			hotel.setCity(city);
			hotel.setHotelName(hotelName);
			hotel.setAddress(addressHotel);
			hotel.setDescription(description);;
			hotel.setAvgRatePerNight(nightRate);
			hotel.setPhoneNo1(phoneOne);
			hotel.setPhoneNo2(phoneTwo);
			hotel.setRating(rating);;
			hotel.setEmail(emailHotel);
			hotel.setFax(fax);
			
			try 
			{
				hotelService.addHotel(hotel);
			}
			catch (HotelException e) 
			{
				request.getSession().setAttribute("error", e.getMessage());
				e.printStackTrace();
			}
			
			HttpSession sessionH = request.getSession();
			sessionH.setAttribute("hotel",hotel);
			
			url="Success.jsp";
			break;
			
		case "/ViewHotel.hb":
		List<Hotel>hlist=hotelService.showAllHotels();
		request.setAttribute("hlist", hlist);
		url="ViewHotel.jsp";
		break;
		
		case "/RemoveHotel.hb":
			String hid=request.getParameter("hotelId");
			HttpSession sess=request.getSession(true);
			 System.out.println(sess);
			sess.setAttribute("hid", hid);
			hotelService.removeHotel(hid);
			url="Success.jsp";
			break;
			
		case "/viewBooking.hb":
			List<BookingDetails>blist=hotelService.showAllBookings();
			request.setAttribute("blist", blist);
			url="ViewBookingDetails.jsp";
			break;
			
		case "/viewRoom.hb":
			List<RoomDetails>Rdlist=hotelService.showAllRooms();
			request.setAttribute("Rdlist", Rdlist);
			url="ViewRoomDetails.jsp";
			break;
			
		case"/addRoom.hb":
			String hotelId = request.getParameter("hotelId");
			String roomId =request.getParameter("room_id");
			String roomType = request.getParameter("roomType");
			Float perNightRate = Float.parseFloat(request.getParameter("perNightRate"));
			String availability = request.getParameter("availability");
			String action1=request.getParameter("Action");
			
		
			RoomDetails room =new RoomDetails();
			
			room.setHotelId(hotelId);
			room.setRoomId(roomId);
			room.setRoomType(roomType);
			room.setPerNightRate(perNightRate);
			room.setAvailability(availability);
			room.setPhoto(action1);
			
/*			hotelService.addRoomDetails(room);
*/			
			try 
			{
				hotelService.addRoomDetails(room);
			}
			catch (HotelException e) 
			{
				request.getSession().setAttribute("error", e.getMessage());
				e.printStackTrace();
			}
			
			HttpSession session = request.getSession();
			session.setAttribute("room",room);
			
			url="Success.jsp";
			break;
		case"/getRoomById.hb":
			String roomId1=request.getParameter("txtRoom");
			//HttpSession sess1=request.getSession(true);
			RoomDetails roomDetails=hotelService.getRoomDetails(roomId1);
			System.out.println(roomDetails);
			//System.out.println(sess1);
			request.setAttribute("roomDetails", roomDetails);
			url="showRoomDetailsById.jsp";

			
			
			
			
	}
	
	
		RequestDispatcher rd = request.getRequestDispatcher(url) ;
		rd.forward(request, response);

}

}